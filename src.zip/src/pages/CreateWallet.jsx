import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  generateSeedPhrase,
  deriveAllWallets,
} from "../services/walletService";
import { saveWallet } from "../services/encryptionService";

export default function CreateWallet() {
  const [step, setStep] = useState(1);
  const [seedPhrase, setSeedPhrase] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleGenerateSeed = () => {
    const newSeed = generateSeedPhrase();
    setSeedPhrase(newSeed);
    setStep(2);
  };

  const handleSaveWallet = async () => {
    if (password !== confirmPassword) {
      setError("Les mots de passe ne correspondent pas");
      return;
    }
    if (password.length < 6) {
      setError("Le mot de passe doit faire au moins 6 caractères");
      return;
    }

    try {
      const wallets = deriveAllWallets(seedPhrase);
      const walletData = {
        seedPhrase: seedPhrase,
        ...wallets,
        createdAt: new Date().toISOString(),
      };

      saveWallet(walletData, password);
      navigate("/dashboard");
    } catch (err) {
      setError("Erreur lors de la création du wallet");
    }
  };

  return (
    <div className="container">
      <div className="card">
        <h1>🚀 Créer SANGOWALLET</h1>

        {step === 1 && (
          <div className="step">
            <p>Bienvenue sur SANGOWALLET, votre wallet multi-blockchains</p>
            <button className="btn-primary" onClick={handleGenerateSeed}>
              Générer 12 mots secrets
            </button>
          </div>
        )}

        {step === 2 && (
          <div className="step">
            <h2>⚠️ Sauvegardez ces 12 mots !</h2>
            <div className="seed-box">{seedPhrase}</div>
            <div className="warning">
              ⚠️ Ces mots permettent de restaurer votre wallet. Perdre ces mots
              = perte définitive de vos cryptos.
            </div>

            <input
              type="password"
              placeholder="Mot de passe wallet"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="input-field"
            />
            <input
              type="password"
              placeholder="Confirmer mot de passe"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className="input-field"
            />

            {error && <div className="error">{error}</div>}

            <button className="btn-success" onClick={handleSaveWallet}>
              Créer mon wallet
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
