import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  loadWallet,
  getSessionWallet,
  setSessionWallet,
} from "../services/encryptionService";
import { getEthBalance, getUsdtBalance } from "../services/ethService";
import { getSolBalance } from "../services/solService";

export default function Dashboard() {
  const [walletData, setWalletData] = useState(null);
  const [balances, setBalances] = useState({});
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const session = getSessionWallet();
    if (session) {
      setWalletData(session);
      fetchBalances(session);
    }
  }, []);

  const handleUnlock = async () => {
    setLoading(true);
    const data = loadWallet(password);
    if (!data) {
      setError("Mot de passe incorrect");
      setLoading(false);
      return;
    }
    setWalletData(data);
    setSessionWallet(data);
    await fetchBalances(data);
    setLoading(false);
  };

  const fetchBalances = async (data) => {
    try {
      const [eth, usdt, sol] = await Promise.all([
        getEthBalance(data.ethAddress),
        getUsdtBalance(data.ethAddress),
        getSolBalance(data.solAddress),
      ]);

      setBalances({ eth, usdt, sol, btc: "0" });
    } catch (error) {
      console.error("Erreur chargement balances");
    }
  };

  if (!walletData) {
    return (
      <div className="container">
        <div className="card">
          <h1>🔐 SANGOWALLET</h1>
          <input
            type="password"
            placeholder="Mot de passe"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="input-field"
            onKeyPress={(e) => e.key === "Enter" && handleUnlock()}
          />
          {error && <div className="error">{error}</div>}
          <button
            className="btn-primary"
            onClick={handleUnlock}
            disabled={loading}
          >
            {loading ? "Déverrouillage..." : "Déverrouiller"}
          </button>
          <button className="btn-secondary" onClick={() => navigate("/import")}>
            Importer un wallet
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="container">
      <div className="dashboard">
        <h1>📊 Tableau de bord</h1>

        <div className="balances-grid">
          <div className="balance-card btc">
            <h3>₿ Bitcoin (BTC)</h3>
            <p className="amount">{balances.btc} BTC</p>
            <small className="address">
              {walletData.btcAddress?.slice(0, 20)}...
            </small>
          </div>

          <div className="balance-card eth">
            <h3>Ξ Ethereum (ETH)</h3>
            <p className="amount">{parseFloat(balances.eth).toFixed(4)} ETH</p>
            <small className="address">
              {walletData.ethAddress?.slice(0, 20)}...
            </small>
          </div>

          <div className="balance-card usdt">
            <h3>💵 Tether (USDT)</h3>
            <p className="amount">
              {parseFloat(balances.usdt).toFixed(2)} USDT
            </p>
            <small>ERC20</small>
          </div>

          <div className="balance-card sol">
            <h3>◎ Solana (SOL)</h3>
            <p className="amount">{parseFloat(balances.sol).toFixed(4)} SOL</p>
            <small className="address">
              {walletData.solAddress?.slice(0, 20)}...
            </small>
          </div>
        </div>

        <div className="actions">
          <button className="btn-primary" onClick={() => navigate("/send")}>
            📤 Envoyer
          </button>
          <button
            className="btn-secondary"
            onClick={() => navigate("/receive")}
          >
            📥 Recevoir
          </button>
        </div>
      </div>
    </div>
  );
}
