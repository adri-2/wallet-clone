import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  deriveAllWallets,
  validateSeedPhrase,
} from "../services/walletService";
import { saveWallet } from "../services/encryptionService";

export default function ImportWallet() {
  const [seedInput, setSeedInput] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleImport = () => {
    if (!validateSeedPhrase(seedInput)) {
      setError("Veuillez entrer exactement 12 mots");
      return;
    }
    if (password.length < 6) {
      setError("Le mot de passe doit faire au moins 6 caractères");
      return;
    }

    try {
      const wallets = deriveAllWallets(seedInput);
      const walletData = {
        seedPhrase: seedInput,
        ...wallets,
        importedAt: new Date().toISOString(),
      };

      saveWallet(walletData, password);
      navigate("/dashboard");
    } catch (err) {
      setError("Seed phrase invalide");
    }
  };

  return (
    <div className="container">
      <div className="card">
        <h1>🔑 Importer un wallet</h1>

        <textarea
          rows={4}
          placeholder="Collez vos 12 mots ici..."
          value={seedInput}
          onChange={(e) => setSeedInput(e.target.value)}
          className="input-field"
        />

        <input
          type="password"
          placeholder="Nouveau mot de passe wallet"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="input-field"
        />

        {error && <div className="error">{error}</div>}

        <button className="btn-primary" onClick={handleImport}>
          Restaurer mon wallet
        </button>

        <button className="btn-secondary" onClick={() => navigate("/create")}>
          Créer un nouveau wallet
        </button>
      </div>
    </div>
  );
}
