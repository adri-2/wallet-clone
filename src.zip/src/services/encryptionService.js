import CryptoJS from "crypto-js";

const STORAGE_KEY = "sangowallet_data";
const SESSION_KEY = "sangowallet_session";

// Sauvegarder wallet chiffré
export const saveWallet = (walletData, password) => {
  const jsonString = JSON.stringify(walletData);
  const encrypted = CryptoJS.AES.encrypt(jsonString, password).toString();
  localStorage.setItem(STORAGE_KEY, encrypted);
  return true;
};

// Charger et déchiffrer wallet
export const loadWallet = (password) => {
  const encrypted = localStorage.getItem(STORAGE_KEY);
  if (!encrypted) return null;

  try {
    const bytes = CryptoJS.AES.decrypt(encrypted, password);
    const decrypted = bytes.toString(CryptoJS.enc.Utf8);
    if (!decrypted) return null;
    return JSON.parse(decrypted);
  } catch (error) {
    console.error("Mot de passe incorrect");
    return null;
  }
};

// Vérifier si un wallet existe
export const walletExists = () => {
  return localStorage.getItem(STORAGE_KEY) !== null;
};

// Gestion de session
export const setSessionWallet = (walletData) => {
  sessionStorage.setItem(SESSION_KEY, JSON.stringify(walletData));
};

export const getSessionWallet = () => {
  const data = sessionStorage.getItem(SESSION_KEY);
  return data ? JSON.parse(data) : null;
};

export const clearSession = () => {
  sessionStorage.removeItem(SESSION_KEY);
};

export const deleteWallet = () => {
  localStorage.removeItem(STORAGE_KEY);
  sessionStorage.removeItem(SESSION_KEY);
};
